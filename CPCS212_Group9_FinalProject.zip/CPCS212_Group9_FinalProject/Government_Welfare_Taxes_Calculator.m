diary Government_Welfare_Expenditure_Calculator.txt
% For prin Welcoming massege
fprintf('\n=====================================================================')
fprintf('\n  ***** Welcome to Government Welfare Expenditure Calculator *****\n')
fprintf('=====================================================================\n')
% Set of Years
Year = [1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995];
% Set of Expenditures in billions of dollars
Expenditures = [731, 782, 833, 886, 956, 1049, 1159, 1267, 1367, 1436, 1505];
Table=[Year' Expenditures'];
fprintf('\n                  Expenditures \n        Year      in billions of dollars\n\n')
disp(Table)
% Ask the user if they want to start the Calculator or exit
Kay='\n\nSelect:\n     1: To Start The Calculator\n     0: To Exit.\n     ----->> ';
kay1=input(Kay);
while kay1 == 1
    % Ask the user to enter the year they want to know their expenditures 
    YearFound = input('\nPlease enter the year you want to know their expenditure : ');
    % Check if the matrix of years contain input year 
    ContainsYear = any(Year(:) == YearFound);    
    % If ContainsYear == 1 ---> the method will be used is Liner Interpolation
    if ContainsYear == 1
        fprintf('\n- Based on the above data, we can estimate the expected expenditure for %d%s',YearFound,' using the interpolation formula.')
        slope = (Expenditures(2) - Expenditures(1)) / (Year(2) - Year(1));
        ExpenditureFound = Expenditures(1) + slope * (YearFound - Year(1));
        % find the index of year to find the actual value from table
        index = find(Year==YearFound); 
        ActualValue = Expenditures(index);       
    % If ContainsYear == 0 ---> the method will be used is Liner Extrapolation    
    elseif ContainsYear == 0
         fprintf('\n- Based on the above data, we can estimate the expected expenditure for %d%s',YearFound,' using the Extrapolation formula.')
         fprintf('\n     * Because the year is out of data *\n')
         ExpenditureFound = Expenditures(1) + (YearFound - Year(1)) / (Year(2) - Year(1)) * (Expenditures(2) - Expenditures(1)); 
         
    end
    % Ask usre if they want to compate result with the actual value ,OR the solution in detail or not
    Select='\n\nSelect:\n     1: To Show The Final Result.\n     2: To Compare The Result With The Amount Actually Spent.\n     3: Both 1 & 2\n     ----->> ';
    Select1=input(Select);
    % Fainal result
    if Select1 == 1
        fprintf('\nThe Expected Expenditure For %d%s%d%s',YearFound,' is ',ExpenditureFound,' Billions Of Dollars.')
        
    % To compare actual value and find the relative error
    elseif Select1 == 2
        % If use Extrapolation methd find the actual value from user
        if ContainsYear == 0
            ActualValue = input('\nPlease enter the amount actually spent: ');
        end
        Compare = abs((ActualValue-ExpenditureFound)/ActualValue)*100;
        fprintf('\nThe result is %d%s%d%s',ExpenditureFound,' and the amount actually spent is ',ActualValue)  
        fprintf('\nThe difference and error rate between the result and the amount actually spent is %.2f%s',Compare,'% .')
     % To Show both 1 and 2 
     elseif Select1 == 3
         fprintf('\nThe Expected Expenditure For %d%s%d%s',YearFound,' is ',ExpenditureFound,' Billions Of Dollars.')
         % If use Extrapolation methd find the actual value from user
        if ContainsYear == 0
            ActualValue = input('\nPlease enter the amount actually spent: ');
        end
        Compare = abs((ActualValue-ExpenditureFound)/ActualValue)*100;
        fprintf('\nThe result is %d%s%d%s',ExpenditureFound,' and the amount actually spent is ',ActualValue)  
        fprintf('\nThe difference and error rate between the result and the amount actually spent is %.2f%s',Compare,'% .')
    end
        % For plot the each point
        plot(Year,Expenditures,'b')
        xlabel('Year')
        ylabel('Expenditures in billions of dollars')
        title('Government Welfare Expenditures')
        grid on
        hold on
        plot(YearFound,ExpenditureFound,'r*')
        plot(YearFound,ActualValue,'g*')
        legend('','Approximate Amount Spent','Amount Actually Spent');
        
    % Ask the user agen to enter the year they want to know their expenditures 
    kay1=input(Kay);
end
% For prin ending massege
fprintf('\n=====================================================================')
fprintf('\n  Thank you for using Government Welfare Expenditure Calculator   \n')
fprintf('=====================================================================\n')
